<?php
/**
 * Legacy class - must be removed 6 month from now - 10.04.2022.
 *
 * @package    wp2fa
 * @subpackage settings
 * @copyright  2021 WP White Security
 * @license    https://www.apache.org/licenses/LICENSE-2.0 Apache License 2.0
 * @link       https://wordpress.org/plugins/wp-2fa/
 */

namespace WP2FA\Admin;

/**
 * Class for handling settings
 */
class SettingsPage extends Settings_Page {

}
